using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 8f;
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        Vector3 dir = new Vector3(h, 0, v).normalized;
        rb.MovePosition(transform.position + dir * moveSpeed * Time.fixedDeltaTime);

        // Rotate to face movement direction
        if (dir != Vector3.zero)
            transform.rotation = Quaternion.LookRotation(dir);
    }
}