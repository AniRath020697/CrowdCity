using UnityEngine;

public class FollowerUnit : MonoBehaviour
{
    private Transform target;
    private int indexInCrowd;
    public float followSpeed = 7f;
    public float spacing = 1.5f;
    public bool isPlayerFollower = false;
    public bool isEnemy = false;

    private CrowdManager crowdManager;

    public void SetTarget(Transform t, int index, CrowdManager manager)
    {
        target = t;
        indexInCrowd = index;
        crowdManager = manager;
    }

    void Update()
    {
        if (target == null) return;

        // Follow behind target with spacing
        Vector3 targetPos = target.position - target.forward * spacing * (indexInCrowd + 1);
        targetPos.y = transform.position.y;
        transform.position = Vector3.MoveTowards(transform.position, targetPos, followSpeed * Time.deltaTime);

        // Face movement direction
        Vector3 dir = (targetPos - transform.position).normalized;
        if (dir != Vector3.zero)
            transform.rotation = Quaternion.LookRotation(dir);
    }

    void OnTriggerEnter(Collider other)
    {
        // NPC joins player crowd
        if (!isPlayerFollower && !isEnemy && other.CompareTag("Player"))
        {
            crowdManager = FindObjectOfType<CrowdManager>();
            crowdManager.AddFollower(gameObject, true);
        }

        // Steal enemy followers if player crowd is bigger
        if (isPlayerFollower && other.CompareTag("EnemyFollower"))
        {
            CrowdManager cm = FindObjectOfType<CrowdManager>();
            if (cm.playerFollowers.Count > cm.enemyFollowers.Count)
            {
                cm.StealFollower(other.gameObject);
            }
        }
    }
}