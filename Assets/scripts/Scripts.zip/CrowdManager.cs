using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections.Generic;

public class CrowdManager : MonoBehaviour
{
    public static CrowdManager Instance;

    public List<GameObject> playerFollowers = new List<GameObject>();
    public List<GameObject> enemyFollowers = new List<GameObject>();

    public Transform player;
    public GameObject followerPrefab;
    public GameObject enemyPrefab;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI timerText;

    public float gameTime = 60f;
    private float timeLeft;
    private bool gameOver = false;

    public int npcCount = 20; // NPCs scattered around map
    public float spawnRange = 40f;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        timeLeft = gameTime;
        SpawnNPCs();
        SpawnEnemyCrowd();
        UpdateScore();
    }

    void Update()
    {
        if (gameOver) return;

        timeLeft -= Time.deltaTime;
        timerText.text = "Time: " + Mathf.CeilToInt(timeLeft);

        if (timeLeft <= 0)
        {
            gameOver = true;
            if (playerFollowers.Count >= enemyFollowers.Count)
                SceneManager.LoadScene("Win");
            else
                SceneManager.LoadScene("Lose");
        }
    }

    void SpawnNPCs()
    {
        for (int i = 0; i < npcCount; i++)
        {
            float x = Random.Range(-spawnRange, spawnRange);
            float z = Random.Range(-spawnRange, spawnRange);
            GameObject npc = Instantiate(followerPrefab, new Vector3(x, 1, z), Quaternion.identity);
            npc.GetComponent<Renderer>().material.color = Color.grey;
            npc.tag = "NPC";

            // Add trigger collider
            SphereCollider sc = npc.GetComponent<SphereCollider>();
            if (sc == null) sc = npc.AddComponent<SphereCollider>();
            sc.isTrigger = true;
            sc.radius = 1.5f;
        }
    }

    void SpawnEnemyCrowd()
    {
        // Spawn enemy leader
        float ex = Random.Range(-spawnRange, spawnRange);
        float ez = Random.Range(-spawnRange, spawnRange);
        GameObject enemy = Instantiate(enemyPrefab, new Vector3(ex, 1, ez), Quaternion.identity);
        enemy.tag = "Enemy";

        // Spawn some enemy followers
        for (int i = 0; i < 5; i++)
        {
            float x = ex + Random.Range(-3f, 3f);
            float z = ez + Random.Range(-3f, 3f);
            GameObject ef = Instantiate(followerPrefab, new Vector3(x, 1, z), Quaternion.identity);
            ef.GetComponent<Renderer>().material.color = Color.red;
            ef.tag = "EnemyFollower";
            enemyFollowers.Add(ef);

            FollowerUnit fu = ef.GetComponent<FollowerUnit>();
            if (fu == null) fu = ef.AddComponent<FollowerUnit>();
            fu.isEnemy = true;

            if (i == 0)
                fu.SetTarget(enemy.transform, i, this);
            else
                fu.SetTarget(ef.transform, i, this);
        }
    }

    public void AddFollower(GameObject npc, bool isPlayerFollower)
    {
        if (isPlayerFollower)
        {
            npc.tag = "PlayerFollower";
            npc.GetComponent<Renderer>().material.color = Color.cyan;
            playerFollowers.Add(npc);

            FollowerUnit fu = npc.GetComponent<FollowerUnit>();
            if (fu == null) fu = npc.AddComponent<FollowerUnit>();
            fu.isPlayerFollower = true;

            // Follow last person in crowd
            Transform followTarget = playerFollowers.Count == 1
                ? player
                : playerFollowers[playerFollowers.Count - 2].transform;

            fu.SetTarget(followTarget, playerFollowers.Count - 1, this);
        }

        UpdateScore();
    }

    public void StealFollower(GameObject enemy)
    {
        enemyFollowers.Remove(enemy);
        AddFollower(enemy, true);
        UpdateScore();
    }

    void UpdateScore()
    {
        if (scoreText != null)
            scoreText.text = "Crowd: " + playerFollowers.Count +
                             "  Enemy: " + enemyFollowers.Count;
    }
}