using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;
    public float height = 20f;
    public float smoothSpeed = 5f;

    void LateUpdate()
    {
        if (player == null) return;

        Vector3 target = new Vector3(
            player.position.x,
            height,
            player.position.z - 5f
        );

        transform.position = Vector3.Lerp(
            transform.position, target, smoothSpeed * Time.deltaTime);

        transform.rotation = Quaternion.Euler(60f, 0f, 0f);
    }
}