using UnityEngine;

public class EnemyLeader : MonoBehaviour
{
    public float moveSpeed = 4f;
    private Vector3 targetPos;
    public float wanderRange = 40f;

    void Start()
    {
        SetNewTarget();
    }

    void Update()
    {
        transform.position = Vector3.MoveTowards(
            transform.position, targetPos, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPos) < 1f)
            SetNewTarget();

        Vector3 dir = (targetPos - transform.position).normalized;
        if (dir != Vector3.zero)
            transform.rotation = Quaternion.LookRotation(dir);
    }

    void SetNewTarget()
    {
        float x = Random.Range(-wanderRange, wanderRange);
        float z = Random.Range(-wanderRange, wanderRange);
        targetPos = new Vector3(x, transform.position.y, z);
    }
}